
<style type="text/css">

  h4.update-available {
    color: red;
    margin-bottom: 0;
  }

  ul.update-available {
    list-style: disc inside;
    padding-left: 15px;
    font-weight: normal;
  }

</style>

<h4 class="update-available"><?php _e('Updating is recommended, here\'s why:', 'piklist');?></h4>