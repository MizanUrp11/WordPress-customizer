<?php
/*
Title: Recent Activity
Extend: dashboard_activity
Extend Method: after
*/
?>

<div class="activity-block">

  <hr />

  <h4><?php _e('This dashboard widget has been extended with Piklist.'); ?></h4>

</div>