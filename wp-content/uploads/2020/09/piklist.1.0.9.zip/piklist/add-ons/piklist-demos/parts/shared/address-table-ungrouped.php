
<p>
  <?php echo $data['ungrouped_address_1_addmore']; ?>
  <?php echo $data['ungrouped_address_2_addmore']; ?>,
  <?php echo $data['ungrouped_city_addmore']; ?>,
  <?php echo $data['ungrouped_state_addmore']; ?>,
  <?php echo $data['ungrouped_postal_code_addmore']; ?>
</p>